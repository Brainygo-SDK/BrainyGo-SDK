package com.test;


/**
 * Created by jiantao.tu on 2018/6/1.
 */
public class Test {





    @org.junit.Test
    public void test() throws Exception {
        System.out.println("brainygo Hello Test.");
//
//            byte[] jsonStr = RijindaelUtils.decrypt1(codeStr, commonPwd);
//            InputStream is = new ByteArrayInputStream(jsonStr);

//        byte[] jsonStr = RijindaelUtils.hexStr2Bytes(codeStr);
//        InputStream is = new ByteArrayInputStream(jsonStr);
//        is = new DecodeInputStream(is, commonPwd);
//
////            is = new GZIPInputStream(is, 1024);
////
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        byte[] b = new byte[1024];
//        int len;
//        while ((len = is.read(b, 0, 1024)) != -1) {
//            baos.write(b, 0, len);
//            baos.flush();
//        }
//        is.close();
//        baos.close();
//        String result = baos.toString();
//        System.out.println(result);


//		File file = new File("/Users/huangdong/Desktop/a.txt");
//		OutputStream os = new FileOutputStream(file);
//		os.write(jsonStr);
//		os.flush();
//		os.close();
    }
}
