package com.brainygo.adsdk.example;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.brainygo.adsdk.example.config.Config;
import com.brainygo.adsdk.example.listener.MyCTAdEventListener;
import com.brainygo.base.core.BrainyGoSDK;
import com.facebook.drawee.view.SimpleDraweeView;
import com.brainygo.appwall.BrainyGoAppwall;
import com.brainygo.base.utils.SLog;

/**
 * Created by huangdong on 17/7/17.
 */

public class NewProcessActivity extends Activity {

    private ViewGroup container;
    private ViewGroup adLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_process);

        BrainyGoSDK.adSourceType = "ct";

        loadNativeAd();

        loadInterstitial();

        loadAppwall();

    }

    private void loadInterstitial() {

        findViewById(R.id.bt2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BrainyGoSDK.preloadInterstitialAd(NewProcessActivity.this, Config.slotIdInterstitial,
                        new MyCTAdEventListener() {

                            @Override
                            public void onInterstitialLoadSucceed(com.brainygo.base.core.BrgNative result) {
                                super.onInterstitialLoadSucceed(result);
                            }


                            @Override
                            public void onReceiveAdSucceed(com.brainygo.base.core.BrgNative result) {              //在广告加载成功之后再show,不然会出一个空白
                                if (result != null && result.isLoaded()) {
                                    BrainyGoSDK.showInterstitialAd(result);

                                }

                                super.onReceiveAdSucceed(result);
                            }
                        });
            }
        });


    }


    private void loadNativeAd() {

        container = (ViewGroup) findViewById(R.id.container);                                             //媒体容器
        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局

        findViewById(R.id.bt1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                loadAd();
            }
        });

    }


    public void loadAd() {
        // 获取原生广告，返回一个含有广告的容器
        BrainyGoSDK.getNativeAd(Config.slotIdNative, SampleApplication.context, new MyCTAdEventListener() {
            @Override
            public void onReceiveAdSucceed(com.brainygo.base.core.BrgNative result) {
                if (result == null) {
                    return;
                }
                SLog.e("onReceiveAdSucceed");
                com.brainygo.base.core.BrgAdvanceNative ctAdvanceNative = (com.brainygo.base.core.BrgAdvanceNative) result;
                showAd(ctAdvanceNative);
                super.onReceiveAdSucceed(result);

            }


            @Override
            public void onReceiveAdFailed(com.brainygo.base.core.BrgNative result) {
                SLog.e("onReceiveAdFailed");
                super.onReceiveAdFailed(result);
            }


            @Override
            public void onAdClicked(com.brainygo.base.core.BrgNative result) {
                SLog.e("onAdClicked");
                super.onAdClicked(result);
            }

        });
    }


    private void showAd(final com.brainygo.base.core.BrgAdvanceNative ctAdvanceNative) {
        SimpleDraweeView img = (SimpleDraweeView) adLayout.findViewById(R.id.iv_img);
        SimpleDraweeView icon = (SimpleDraweeView) adLayout.findViewById(R.id.iv_icon);
        TextView title = (TextView) adLayout.findViewById(R.id.tv_title);
        TextView desc = (TextView) adLayout.findViewById(R.id.tv_desc);
        TextView click = (TextView) adLayout.findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = (SimpleDraweeView) adLayout.findViewById(
                R.id.ad_choice_icon);

        img.setImageURI(Uri.parse(ctAdvanceNative.getImageUrl()));
        icon.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
        title.setText(ctAdvanceNative.getTitle());
        desc.setText(ctAdvanceNative.getDesc());
        click.setText(ctAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctAdvanceNative.getAdChoiceIconUrl());

//        ctAdvanceNative.addADLayoutToADContainer(adLayout);
        ctAdvanceNative.registeADClickArea(adLayout);

        container.removeAllViews();
//        container.addView(ctAdvanceNative);
        container.addView(adLayout);
    }


    private void loadAppwall() {

        findViewById(R.id.bt3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                BrainyGoAppwall.showAppwall(SampleApplication.context, Config.slotIdAppWall);

            }
        });


    }


}
