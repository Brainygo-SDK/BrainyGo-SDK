package com.brainygo.adsdk.example.bean;

import com.brainygo.video.core.BrgNativeVideo;

/**
 * Created by huangdong on 16/8/18.
 */
public class News {

    public BrgNativeVideo ctNativeVideo;
    public com.brainygo.base.core.BrgAdvanceNative ctAdvanceNative;
    public String iconUrl;
    public String title;
    public String desc;
    public String choiceUrl;
    public String buttonStr;
    public boolean isAds = false;

}
