package com.brainygo.adsdk.example.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.brainygo.adsdk.example.R;
import com.brainygo.adsdk.example.config.Config;
import com.brainygo.adsdk.example.listener.MyCTAdEventListener;
import com.brainygo.base.core.BrainyGoSDK;

public class InterstitialAdFragment extends Fragment {

    private TextView adStatusTextView;
    private Button loadButton;
    private Button showButton;
    private com.brainygo.base.core.BrgNative interstitial;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.interstitial_ad_layout, null);
        initView(view);
        return view;
    }


    private void initView(View view) {

        adStatusTextView = (TextView) view.findViewById(R.id.statusLabel);

        loadButton = (Button) view.findViewById(R.id.loadButton);
        loadButton.setText("LOAD AD");
        showButton = (Button) view.findViewById(R.id.showButton);
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadAd();
            }
        });

        showButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAd();
            }
        });

    }


    private void showAd() {
        if (BrainyGoSDK.isInterstitialAvailable(interstitial)) {
            BrainyGoSDK.showInterstitialAd(interstitial);
        } else {
            log("Cannot Show Interstitial Ad Not Available");
        }
    }


    private static final String TAG = "InterstitialAdFragment";

    public void loadAd() {

        log("Interstitial Ad Loading...");
        showButton.setEnabled(false);
        // 获取插屏广告，返回一个含有广告的容器
        BrainyGoSDK.preloadInterstitialAd(getContext(), Config.slotIdInterstitial,
                new MyCTAdEventListener() {

                    @Override
                    public void onInterstitialLoadSucceed(com.brainygo.base.core.BrgNative result) {
                        super.onInterstitialLoadSucceed(result);
                    }


                    @Override
                    public void onReceiveAdSucceed(com.brainygo.base.core.BrgNative result) {              //在广告加载成功之后再show,不然会出一个空白
                        if (result != null && result.isLoaded()) {
                            interstitial = result;
                            showButton.setEnabled(true);
                            log("Interstitial Ad Loaded.");
                            Log.w(TAG, "onReceiveAdSucceed");
                            showAd();
                        }

                        super.onReceiveAdSucceed(result);
                    }


                    @Override public void onLandpageShown(com.brainygo.base.core.BrgNative result) {
                        super.onLandpageShown(result);
                        Log.e(TAG, "onLandpageShown:");
                    }


                    @Override
                    public void onReceiveAdFailed(com.brainygo.base.core.BrgNative error) {
                        Log.w(TAG, "onReceiveAdFailed: " + error.getErrorsMsg());
                        log("Interstitial ad failed to load with error msg:: " +
                                error.getErrorsMsg());
                        showButton.setEnabled(false);
                        super.onReceiveAdFailed(error);
                    }


                    @Override
                    public void onAdClosed(com.brainygo.base.core.BrgNative result) {
                        super.onAdClosed(result);
                        interstitial = null;
                        Log.e(TAG, "onAdClosed:");
                    }
                });

    }

    private void log(final String s) {
        if (adStatusTextView != null) {
            Activity activity = getActivity();
            if (!isDetached() && activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adStatusTextView.setText(s);
                    }
                });
            }

        }
        Log.w(TAG, "log: " + s);
    }
}
