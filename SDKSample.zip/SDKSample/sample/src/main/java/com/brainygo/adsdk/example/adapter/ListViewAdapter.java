package com.brainygo.adsdk.example.adapter;

import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.brainygo.adsdk.example.R;
import com.brainygo.adsdk.example.SampleApplication;
import com.brainygo.adsdk.example.bean.News;
import com.facebook.drawee.view.SimpleDraweeView;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangdong on 16/8/18.
 */
public class ListViewAdapter extends BaseAdapter {

    public List<News> dataList;


    public ListViewAdapter() {
        dataList = new ArrayList<>();
    }


    @Override
    public int getCount() {
        return dataList.size();
    }


    @Override
    public News getItem(int i) {
        return dataList.get(i);
    }


    @Override
    public long getItemId(int i) {
        return i;
    }


    @Override
    public int getViewTypeCount() {
        return super.getViewTypeCount() + 1;
    }


    @Override
    public int getItemViewType(int position) {
        News news = dataList.get(position);
        if (news.isAds) {
            return 0;
        } else {
            return 1;
        }
    }


    @Override
    public View getView(int position, View contentView, ViewGroup viewGroup) {

        if (contentView == null) {
            contentView = View.inflate(SampleApplication.context, R.layout.item_advance_ad_list,
                    null);
        }

        SimpleDraweeView icon = (SimpleDraweeView) contentView.findViewById(R.id.iv_icon);
        TextView tv_title = (TextView) contentView.findViewById(R.id.tv_title);
        TextView tv_desc = (TextView) contentView.findViewById(R.id.tv_desc);

        News news = dataList.get(position);
        if(news.iconUrl!=null) icon.setImageURI(Uri.parse(news.iconUrl));
        if(news.title!=null) tv_title.setText(news.title);
        if(news.desc!=null) tv_desc.setText(news.desc);
        if (news.isAds) {

            com.brainygo.base.core.BrgAdvanceNative ctAdvanceNative = news.ctAdvanceNative;
            ctAdvanceNative.registeADClickArea(contentView);

        }

        return contentView;

    }


    public void setDate(List<News> aList) {

        if (aList != null) {
            dataList = aList;
        }

        notifyDataSetChanged();

    }

}

