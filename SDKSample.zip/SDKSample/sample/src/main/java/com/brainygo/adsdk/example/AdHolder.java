package com.brainygo.adsdk.example;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static com.brainygo.base.vo.AdsNativeVO adNativeVO = null;

}
