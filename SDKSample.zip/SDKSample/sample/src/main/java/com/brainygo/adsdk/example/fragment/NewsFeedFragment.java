package com.brainygo.adsdk.example.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.brainygo.adsdk.example.R;

public class NewsFeedFragment extends Fragment implements View.OnClickListener {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_newsfeed, null);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        // NewsFeedHelper.setCustomThemeColor(getResources().getColor(R.color.colorPrimary));
        // NewsFeedHelper.setCustomTitleTextColor(Color.WHITE);
        // NewsFeedHelper.setCustomTitleHeightDip(55);
    }


    public void initView(View v) {
        v.findViewById(R.id.show_news_feed).setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        // initialize
        // NewsFeedHelper.initialize(getActivity());

        // createFragment
        // NewsFragment fragment = NewsFeedHelper.createFragment(Config.slotIdNative);

        // // set news item click callback
        // fragment.setOnNewsClickListener(new OnNewsClickListener() {
        //     @Override
        //     public void onNewItemClick(String detailUrl) {
        //         Intent intent = new Intent(Intent.ACTION_VIEW);
        //         intent.setData(Uri.parse(detailUrl));
        //         getContext().startActivity(intent);
        //     }
        // });
        // MainActivity mainActivity = (MainActivity) getActivity();
        // mainActivity.showFragment(fragment);

    }
}
