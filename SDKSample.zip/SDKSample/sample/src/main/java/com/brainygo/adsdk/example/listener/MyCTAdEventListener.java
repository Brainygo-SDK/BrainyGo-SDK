package com.brainygo.adsdk.example.listener;

import android.util.Log;
import android.widget.Toast;

import com.brainygo.base.callback.AdEventListener;

public class MyCTAdEventListener extends AdEventListener {

    @Override
    public void onReceiveAdSucceed(com.brainygo.base.core.BrgNative result) {
        showMsg("onReceiveAdSucceed");
    }

    @Override
    public void onReceiveAdVoSucceed(com.brainygo.base.vo.AdsNativeVO result) {
        showMsg("onReceiveAdVoSucceed");
    }

    @Override
    public void onInterstitialLoadSucceed(com.brainygo.base.core.BrgNative result) {
        showMsg("onInterstitialLoadSucceed");
    }

    @Override
    public void onReceiveAdFailed(com.brainygo.base.core.BrgNative result) {
        showMsg(result.getErrorsMsg());
        Log.i("sdksample", "==error==" + result.getErrorsMsg());
    }

    @Override
    public void onLandpageShown(com.brainygo.base.core.BrgNative result) {
        showMsg("onLandpageShown");
    }

    @Override
    public void onAdClicked(com.brainygo.base.core.BrgNative result) {
        showMsg("onAdClicked");
    }

    @Override
    public void onAdClosed(com.brainygo.base.core.BrgNative result) {
        showMsg("onAdClosed");
    }


    private void showMsg(String msg) {
        showToast(msg);
    }


    public static void showToast(String text) {
        // Toast.makeText(SampleApplication.context, text, Toast.LENGTH_SHORT).show();
    }


    private static Toast toast;

}
